# Validation — repeated dispensing update (v9)

253 distinct automated checks passed:
- 131 parser/encoder checks
- 57 graph-editor model checks
- 29 UI DOM-adapter checks
- 22 editor UI DOM-adapter checks
- 14 repeated-dispense checks

New coverage includes 20 draws from a source over 20 mixing stages, per-draw port/value preservation, compact editor round-trip, undo/redo, expanded code/graph agreement, unique generated IDs, output block membership, idempotence, immutability and the 500-node expanded-size guard. Processing-operation fanout, duplicate references, and unused sources remain invalid.

The 20-draw example has 23 compact protocol nodes and 41 edges; the execution graph has 42 nodes and 41 edges, including 20 distinct DISPENSE occurrences from i1 and one from i2.

Both index.html and embedded standalone.html were exercised with DOM adapters. No real-browser, external SSS, scheduling, or physical-device execution is claimed. Existing source units and molecular quantities are not changed.

Run: node test.js; node test-editor.js; node test-ui.js; node test-editor-ui.js; node test-dispense.js. The editor UI test imports and repeats the UI suite; that repetition is not counted twice.
