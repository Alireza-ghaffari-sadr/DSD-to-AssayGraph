/* Embedded examples: also written as .dsd files by build.py. */
(function(root){'use strict';const examples=[
{name:'Three-input mixture',file:'01-three-input.dsd',source:`directive simulation { final=600; plots=[Sample();Buffer();Reagent()]; }
def Sample() = <t^ sample>
def Buffer() = <t^ buffer>
def Reagent() = <t^ reagentA>

// Initial quantities are not droplet volumes or operation values.
(
  10 Sample() // @node fluid=i1
| 20 Buffer() // @node fluid=i2
| 5 Reagent() // @node fluid=t1
) // @node output=output1 @heat value=1 @detect count=1 value=1
`},
{name:'Explicit MIX → SPLIT → two outputs',file:'02-explicit-split.dsd',source:`def Sample() = <t^ sample>
def Buffer() = <t^ buffer>
def Reagent() = <t^ reagentA>

(
  10 Sample() // @node id=A fluid=i1
| 10 Buffer() // @node id=B fluid=i2
| 10 Reagent() // @node id=C fluid=t1

// These comments specify physical operations; they are not DSD reactions.
// @mix id=M1 inputs=A,B value=4 @heat value=1 @detect value=1
// @split id=S1 input=M1 value=1
// @mix id=M2 inputs=S1,C @heat value=1 @detect value=1
// @output id=OUT1 input=M2 output=output1
// @output id=OUT2 input=S1 output=output2
)
`},
{name:'Join gate: initial preparation',file:'03-join-preparation.dsd',source:`directive simulation {
  final=600;
  plots=[Input1();Input2();Output();Signal()];
}
directive simulator deterministic
directive parameters [k=0.003;u=0.1]
directive compilation infinite
dom tb = {bind=k;unbind=u;colour="red"}
dom tx = {bind=k;unbind=u;colour="green"}
dom to = {bind=k;unbind=u;colour="blue"}
def Input1() = <tb^ b>
def Input2() = <tx^ x>
def Output() = <x to^>
def Join() = {tb^*}[b tx^]:[x to^]
def Reporter() = <fl^>[x]{to^*}
def Signal() = <fl^ x>
(
  10 Input1() // @node fluid=i1
| 10 Input2() // @node fluid=i2
| 0 Output()
| 100 Join() // @node fluid=t1
| 100 Reporter() // @node fluid=t2
| 0 Signal()
) // @node output=output1 @detect value=5
`},
{name:'Join gate: continuous source/sink (partial)',file:'04-join-dynamic.dsd',source:`directive simulation {
  final=600;
  plots=[Input1();Input2();Output();Signal()];
}
directive simulator deterministic
directive parameters [k=0.003;u=0.1;r=0.01]
directive compilation infinite
dom tb = {bind=k;unbind=u;colour="red"}
dom tx = {bind=k;unbind=u;colour="green"}
dom to = {bind=k;unbind=u;colour="blue"}
def Input1() = <tb^ b>
def Input2() = <tx^ x>
def Output() = <x to^>
def Join() = {tb^*}[b tx^]:[x to^]
def Reporter() = <fl^>[x]{to^*}
def Signal() = <fl^ x>
( 0 Input1()
| ->{0.1} Input1()
| Input1() ->{0.01}
| Output() + Reporter() ->{r} [x to^] + Signal()
| 10 Input2()
| 0 Output()
| 100 Join()
| 100 Reporter()
| 0 Signal()
)
`},
{name:'Nested groups and multiple blocks',file:'05-multiple-blocks.dsd',source:`def A() = <a>
def B() = <b>
def C() = <c>
def D() = <d>
// Separate top-level blocks are shown as independent preparations.
(
  ( 10 A() // @node fluid=i1
  | 10 B() // @node fluid=i2
  ) // @node value=4 @heat value=2
| 10 C() // @node fluid=t1
) // @node output=output1 @detect value=3

( 5 D() // @node fluid=t2
) // @node output=output2
`},
{name:'Parameterized invoked process',file:'06-parameterized-process.dsd',source:`directive parameters [N=10;M=2*N]
def Strand(x) = <t^ x>
def Unused() = <unused>
def Preparation(n,x) = (
  n Strand(x) // @node fluid=i1
| M Strand(buffer) // @node fluid=i2
)
// Only the invoked process is expanded. Unused() creates no node.
Preparation(N,sample) // @node output=output1 @heat value=2
`},
{name:'Literal molecules and comments',file:'07-literal-strands.dsd',source:`(* A comment may contain (fake processes) and nested (* comments *). *)
(
  1e1 <t^ sample> // @node fluid=i1 value=2
| 2.5 <t^ buffer> // @node fluid=i2
| 0 <t^ absent>
) // @node output=output1 @detect
`},
{name:'Explicit molecular reaction (metadata)',file:'08-reaction-metadata.dsd',source:`directive parameters [k=0.003]
def A() = <t^ a>
def B() = <u^ b>
def C() = <v^ c>
(
  10 A() // @node fluid=i1
| 10 B() // @node fluid=i2
| 0 C()
| A() + B() ->{k} C()
) // @node output=output1 @detect value=5
`}
,{"name": "Repeated dispense \u2014 two draws", "file": "11-repeated-dispense.dsd", "source": "def Sample() = <t^ sample>\ndef Buffer() = <t^ buffer>\n(\n  10 Sample() // @node id=A fluid=i1 value=1\n| 10 Buffer() // @node id=B fluid=i2 value=1\n// @mix id=M1 inputs=A,B value=4\n// @mix id=M2 inputs=A,M1 value=4\n// @output id=OUT input=M2 output=output1\n)"},{"name": "Repeated dispense \u2014 20 draws", "file": "12-twenty-draws.dsd", "source": "def Stock() = <t^ stock>\ndef Buffer() = <t^ buffer>\n(\n  10 Stock() // @node id=A fluid=i1 value=2\n| 10 Buffer() // @node id=B fluid=i2 value=1\n// @mix id=M1 inputs=A,B value=4\n// @mix id=M2 inputs=A,M1 value=4\n// @mix id=M3 inputs=A,M2 value=4\n// @mix id=M4 inputs=A,M3 value=4\n// @mix id=M5 inputs=A,M4 value=4\n// @mix id=M6 inputs=A,M5 value=4\n// @mix id=M7 inputs=A,M6 value=4\n// @mix id=M8 inputs=A,M7 value=4\n// @mix id=M9 inputs=A,M8 value=4\n// @mix id=M10 inputs=A,M9 value=4\n// @mix id=M11 inputs=A,M10 value=4\n// @mix id=M12 inputs=A,M11 value=4\n// @mix id=M13 inputs=A,M12 value=4\n// @mix id=M14 inputs=A,M13 value=4\n// @mix id=M15 inputs=A,M14 value=4\n// @mix id=M16 inputs=A,M15 value=4\n// @mix id=M17 inputs=A,M16 value=4\n// @mix id=M18 inputs=A,M17 value=4\n// @mix id=M19 inputs=A,M18 value=4\n// @mix id=M20 inputs=A,M19 value=4\n// @output id=OUT input=M20 output=output1\n)"}];if(typeof module!=='undefined'&&module.exports)module.exports=examples;else root.DSDExamples=examples;})(typeof globalThis!=='undefined'?globalThis:this);
