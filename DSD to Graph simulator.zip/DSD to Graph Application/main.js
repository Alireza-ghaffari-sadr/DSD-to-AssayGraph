/* Main-process extraction and explicit DMFB protocol lowering. No DSD kinetics compiler. */
(function(root){'use strict';
const INPUT_PORTS=Object.freeze(['i1','i2','i3','i4','i5','t1','t2','t3','t4','t5']);
const OUTPUT_PORTS=Object.freeze(['output1','output2','output3','output4','output5']);
class ParseError extends Error{constructor(message,t){super(message);this.name='ParseError';this.line=t?.line||1;this.column=t?.col||1;}}
const fail=(s,t)=>{throw new ParseError(s,t);};
const OPEN={'(':')','[':']','{':'}','<':'>'},CLOSE=new Set(Object.values(OPEN));
function lex(source){
 if(typeof source!=='string')fail('Source must be text.');if(source.length>500000)fail('Source exceeds 500,000 characters.');
 const out=[];let i=0,line=1,col=1;const step=()=>{const c=source[i++];if(c==='\n'){line++;col=1;}else col++;return c;};
 while(i<source.length){if(out.length>100000)fail('Token limit exceeded.',{line,col});if(/\s/.test(source[i])){step();continue;}const start=i,t={line,col,start};let v='',two=source.slice(i,i+2);
  if(two==='//' ){while(i<source.length&&source[i]!=='\n')v+=step();out.push({...t,kind:'comment',v:v.slice(2),end:i});continue;}
  if(two==='(*'||two==='/*'){const stack=[];do{two=source.slice(i,i+2);if(two==='(*'||two==='/*'){stack.push(two==='(*'?'*)':'*/');step();step();}else if(two===stack.at(-1)){stack.pop();step();step();}else step();if(i>=source.length&&stack.length)fail('Unclosed block comment.',t);}while(stack.length);continue;}
  if(source[i]==='"'){v+=step();let closed=false;while(i<source.length){const c=step();v+=c;if(c==='\\'&&i<source.length)v+=step();else if(c==='"'){closed=true;break;}}if(!closed)fail('Unclosed string.',t);out.push({...t,kind:'string',v,end:i});continue;}
  const rest=source.slice(i);let m=rest.match(/^(?:<->|->|::)/);if(m){v=m[0];for(let j=0;j<v.length;j++)step();}
  else if((m=rest.match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/))){v=m[0];for(let j=0;j<v.length;j++)step();out.push({...t,kind:'number',v,end:i});continue;}
  else if((m=rest.match(/^[A-Za-z_][A-Za-z0-9_']*/))){v=m[0];for(let j=0;j<v.length;j++)step();out.push({...t,kind:'id',v,end:i});continue;}
  else v=step();out.push({...t,kind:'symbol',v,end:i});if(out.length>100000)fail('Token limit exceeded.',t);
 }out.push({kind:'eof',v:'EOF',line,col,start:i,end:i});return out;
}
// Restricted arithmetic: deliberately no eval/Function, property access or function calls.
function numberExpr(ts,env,t){let i=0;const peek=()=>ts[i]?.v;function atom(depth){if(depth>40)fail('Numeric expression nesting limit.',t);let x=ts[i++];if(!x)fail('Incomplete numeric expression.',t);if(x.v==='+'||x.v==='-'){const y=atom(depth+1);return x.v==='-'?-y:y;}if(x.v==='('){const y=sum(depth+1);if(peek()!==')')fail('Unclosed numeric expression.',x);i++;return y;}if(x.kind==='number')return Number(x.v);if(x.kind==='id'&&Object.prototype.hasOwnProperty.call(env,x.v)&&typeof env[x.v]==='number')return env[x.v];fail('Unknown numeric parameter: '+x.v+'. Use a numeric parameter or literal.',x);}
 function product(d){let n=atom(d);while(['*','/'].includes(peek())){const op=ts[i++].v,x=atom(d);n=op==='*'?n*x:n/x;}return n;}
 function sum(d){let n=product(d);while(['+','-'].includes(peek())){const op=ts[i++].v,x=product(d);n=op==='+'?n+x:n-x;}return n;}const n=sum(0);if(i!==ts.length||!Number.isFinite(n))fail('Invalid or non-finite numeric expression.',t||ts[i]);return n;
}
function annotations(comments){const result=[];for(const c of comments||[]){const parts=c.v.split('@').slice(1);for(const part of parts){const words=part.trim().replace(/;\s*$/,'').split(/\s+/),kind=words.shift(),a={};if(!['node','heat','detect','duration','mix','split','output'].includes(kind))fail('Unknown annotation @'+kind+'.',c);for(let word of words){word=word.replace(/;$/,'');const m=word.match(/^([a-z]+)=([A-Za-z0-9_.,+'\-]+)$/);if(!m||Object.prototype.hasOwnProperty.call(a,m[1]))fail('Invalid or duplicate annotation option: '+word,c);a[m[1]]=m[2];}
 const allowed={node:['id','fluid','output','value','count'],heat:['id','input','value','time'],detect:['id','input','value','time','count'],duration:['value','time'],mix:['id','inputs','value','count'],split:['id','input','value','count'],output:['id','input','output']}[kind];for(const k of Object.keys(a))if(!allowed.includes(k))fail('Unsupported '+k+' for @'+kind+'.',c);
 if(a.value!==undefined&&a.time!==undefined)fail('Use value or time, not both.',c);
 for(const k of ['value','time','count'])if(a[k]!==undefined){const n=Number(a[k]);if(!Number.isFinite(n)||n<=0||(k==='count'&&!Number.isSafeInteger(n)))fail(k+' must be positive'+(k==='count'?' and an integer':'')+'.',c);a[k]=n;}
 for(const k of ['id','input'])if(a[k]&&!/^[A-Za-z_][A-Za-z0-9_]*$/.test(a[k]))fail('Invalid protocol identifier '+a[k]+'.',c);
 if(a.inputs&&!a.inputs.split(',').every(x=>/^[A-Za-z_][A-Za-z0-9_]*$/.test(x)))fail('inputs must be comma-separated protocol identifiers.',c);
 result.push({kind,...a,line:c.line});}}
 return result;
}
function extract(source){const ts=lex(source);let i=0,depth=0;const defs=new Map(),params={},roots=[],notes=[];const peek=()=>ts[i],take=()=>ts[i++];const need=v=>{if(peek().v!==v)fail('Expected '+v+'; received '+peek().v,peek());return take();};
 function balanced(){const t=take(),close=OPEN[t.v];if(!close)fail('Expected opening delimiter.',t);const result=[t];while(peek().v!==close){if(peek().kind==='eof')fail('Unclosed '+t.v,t);if(CLOSE.has(peek().v))fail('Mismatched delimiter '+peek().v,peek());if(OPEN[peek().v]){if(++depth>64)fail('Nesting limit exceeded.',peek());result.push(...balanced());depth--;}else result.push(take());}result.push(take());return result;}
 function tail(x){while(peek().kind==='comment'&&peek().line===x.endLine)x.comments.push(take());return x;}
 function group(){const start=need('(');if(++depth>64)fail('Process nesting limit exceeded.',start);const items=[],comments=[];let expect=true;
  while(peek().v!==')'){if(peek().kind==='eof')fail('Unclosed main/process block.',start);if(peek().kind==='comment'){const c=take();if(items.length&&items.at(-1).endLine===c.line)items.at(-1).comments.push(c);else comments.push(c);continue;}if(peek().v==='|'){if(expect&&items.length)fail('Empty process between | separators.',peek());take();expect=true;continue;}if(!expect)fail('Expected | between process entries.',peek());const x=item();items.push(x);expect=false;}
  const end=need(')');if(expect&&items.length)fail('Trailing | has no process.',end);depth--;return tail({kind:'group',items,comments,line:start.line,endLine:end.line,start:start.start,end:end.end});}
 function item(){if(peek().v==='(')return group();const start=peek(),tokens=[];
  while(!['|',')','EOF'].includes(peek().v)){if(peek().kind==='comment')break;if(OPEN[peek().v])tokens.push(...balanced());else if(CLOSE.has(peek().v))fail('Unexpected delimiter '+peek().v,peek());else tokens.push(take());}
  if(!tokens.length)fail('Expected a process entry.',start);return tail({kind:'term',tokens,comments:[],line:start.line,endLine:tokens.at(-1).line,start:start.start,end:tokens.at(-1).end});}
 function definition(){const t=need('def'),name=take();if(name.kind!=='id')fail('Expected definition name.',name);need('(');const args=[];while(peek().v!==')'){const a=take();if(a.kind!=='id')fail('Only identifier parameters are supported.',a);args.push(a.v);if(peek().v!==')')need(',');}need(')');need('=');let body;
  if(peek().v==='(')body=group();else{const start=peek(),tokens=[];if(peek().kind==='id'){tokens.push(take());if(peek().v==='(')tokens.push(...balanced());else fail('Definition aliases must be module calls.',start);}else if(['<','[','{'].includes(peek().v)){do{if([':', '::'].includes(peek().v))tokens.push(take());if(!['<','[','{'].includes(peek().v))fail('Incomplete molecular structure.',peek());tokens.push(...balanced());}while(['<','[','{',':','::'].includes(peek().v));}else fail('Unsupported definition body. Use a strand, gate, call or parenthesized process.',peek());body=tail({kind:'term',tokens,comments:[],line:start.line,endLine:tokens.at(-1).line,start:start.start,end:tokens.at(-1).end});}
  if(defs.has(name.v))fail('Duplicate definition '+name.v,name);if(new Set(args).size!==args.length)fail('Duplicate parameter.',name);defs.set(name.v,{name:name.v,args,body,line:t.line});if(defs.size>500)fail('Maximum 500 definitions.',t);
 }
 function declaration(){const t=take(),kind=t.v,name=take();if(kind==='directive'&&(name.v==='spatial'||(name.v==='simulator'&&peek().v==='pde')))notes.push({severity:'error',line:t.line,message:'Spatial simulation is outside this physical preparation subset; spatial effects are not represented.'});if(kind==='directive'&&name.v==='parameters'){if(peek().v!=='[')fail('Expected parameter list.',peek());const list=balanced().slice(1,-1).filter(x=>x.kind!=='comment');let entry=[];function add(){if(!entry.length)return;const [key,eq,...value]=entry;if(key.kind!=='id'||eq?.v!=='=')fail('Invalid parameter declaration.',key);if(value.some(x=>['{','['].includes(x.v))){notes.push({severity:'warning',line:key.line,message:'Complex parameter metadata is not evaluated: '+key.v});}else{if(Object.prototype.hasOwnProperty.call(params,key.v))fail('Duplicate numeric parameter '+key.v,key);params[key.v]=numberExpr(value,params,key);}entry=[];}
 for(const x of list){if(x.v===';')add();else entry.push(x);}add();return;}
  while(peek().kind!=='eof'){if(peek().kind==='comment'){take();break;}if(peek().line>name.line&&!['{','['].includes(peek().v))break;if(['directive','dom','def'].includes(peek().v))break;if(OPEN[peek().v]){balanced();break;}take();}
 }
 let flat=[];function flush(){if(flat.length){roots.push({kind:'group',items:flat,comments:[],line:flat[0].line,endLine:flat.at(-1).endLine,implicit:true,start:flat[0].start,end:flat.at(-1).end});flat=[];}}
 while(peek().kind!=='eof'){
  const p=peek();if(p.kind==='comment'){take();if(p.v.includes('@'))notes.push({severity:'warning',line:p.line,message:'Annotation outside an executable block is not applied.'});continue;}
  if(['directive','dom'].includes(p.v)){flush();declaration();continue;}if(p.v==='def'){flush();definition();continue;}
  if(p.v==='new')fail('Scoped new declarations are not supported by this subset; move the assay preparation into an explicit supported block.',p);
  if(p.v==='|'){take();continue;}if(p.v===';'){take();continue;}if(p.v==='('){flush();roots.push(group());continue;}flat.push(item());
 }flush();if(!roots.length)fail('No executable main process found. Definitions alone do not create an assay. Add ( A() | B() ).');
 return {source,defs,params,roots,notes};
}
function parse(source,options={}){const p=extract(source),nodes=[],edges=[],diagnostics=[...p.notes],observations=[],reactions=[],blocks=[];let serial=0,expanded=0;
 const warn=(message,line=1,severity='warning')=>diagnostics.push({severity,message,line});
 const add=(type,fields={})=>{if(nodes.length>=500)fail('Graph exceeds 500 nodes.',fields);const n={id:++serial,name:type+'_'+serial,type,value:1,...fields};nodes.push(n);return n;};
 const connect=(a,b)=>edges.push({source:a.id,target:b.id});
 const annotationList=x=>annotations(x.comments);
 const baseMeta=as=>{const ms=as.filter(a=>a.kind==='node'||a.kind==='duration');if(ms.length>1)fail('Only one @node or @duration is allowed on an entry.',ms[1]);return ms[0]||{};};
 function applyOps(n,as,origin){let tail=n;for(const a of as.filter(x=>x.kind==='heat'||x.kind==='detect')){const op=add(a.kind.toUpperCase(),{name:n.name+'_'+a.kind.toUpperCase()+'_'+(serial+1),value:a.value??a.time??1,line:a.line,sourceModule:origin,...(a.kind==='detect'?{count:a.count??1}:{})});connect(tail,op);tail=op;}return tail;}
 function subst(tokens,env){return tokens.flatMap(t=>env[t.v]&&Array.isArray(env[t.v])?env[t.v].map(x=>({...x,line:t.line})):t);}
 function termInfo(x,env){let ts=subst(x.tokens,env).filter(t=>t.kind!=='comment');if(ts.some(t=>t.v==='->'||t.v==='<->'))return {kind:'reaction',tokens:ts};
 if(ts.some(t=>t.v==='@')||ts[0]?.v==='constant')return {kind:'dynamic',tokens:ts};
 let start=ts.findIndex((t,j)=>['<','[','{'].includes(t.v)||(t.kind==='id'&&ts[j+1]?.v==='('));
 if(start<0)fail('Unsupported main entry. Expected [quantity] Module() or a strand/gate.',x);
 let amount=ts.slice(0,start);if(amount.at(-1)?.v==='*')amount.pop();const numericEnv={...p.params};for(const [k,v] of Object.entries(env))try{numericEnv[k]=numberExpr(v,numericEnv,x);}catch(_){}
 const quantity=amount.length?numberExpr(amount,numericEnv,x):1;if(quantity<0)fail('Initial quantity cannot be negative.',x);
 const body=ts.slice(start);if(body[0].kind==='id'){
  const name=body[0].v;if(body.at(-1)?.v!==')')fail('Unexpected text after module call. Separate main entries with |.',x);let d=0,args=[[]];for(let j=2;j<body.length-1;j++){const t=body[j];if(t.v==='(')d++;if(t.v===')')d--;if(d<0)fail('Unexpected text after module call.',t);if(t.v===','&&d===0)args.push([]);else args.at(-1).push(t);}if(args.length===1&&!args[0].length)args=[];return {kind:'call',name,args,quantity,tokens:body};
 }
 // Only molecular segments and their connectors may follow an initial quantity.
 let j=0,needSegment=true;while(j<body.length){const t=body[j];if(!['<','[','{'].includes(t.v))fail('Unexpected text outside a molecular segment: '+t.v,t);const stack=[OPEN[t.v]];const begin=j++;while(j<body.length&&stack.length){const v=body[j++].v;if(OPEN[v])stack.push(OPEN[v]);else if(CLOSE.has(v)){if(v!==stack.pop())fail('Mismatched molecular delimiter.',t);}}if(stack.length||j===begin+2)fail('Empty or incomplete molecular segment.',t);needSegment=false;if([':', '::'].includes(body[j]?.v)){j++;needSegment=true;}}if(needSegment)fail('Incomplete molecular connector.',x);return {kind:'molecule',quantity,tokens:body};
 }
 function expand(x,env={},stack=[],factor=1,callLine=null){if(++expanded>2000)fail('Expanded process limit exceeded.',x);if(stack.length>40)fail('Module expansion depth limit.',x);if(x.kind==='group')return {...x,line:callLine||x.line,items:x.items.map(c=>expand(c,env,stack,factor,callLine)),comments:x.comments};
 const info=termInfo(x,env);if(info.kind==='reaction'||info.kind==='dynamic')return {...x,...info,line:callLine||x.line};
 const quantity=info.quantity*factor;if(!Number.isFinite(quantity))fail('Initial quantity overflow.',x);
 if(info.kind==='molecule')return {...x,kind:'species',species:info.tokens.map(t=>t.v).join(' '),quantity,line:callLine||x.line};
 const d=p.defs.get(info.name);if(!d)fail('Undefined module '+info.name+'.',x);if(d.args.length!==info.args.length)fail('Argument count mismatch for '+info.name+'.',x);if(stack.includes(d.name))fail('Recursive module cycle: '+[...stack,d.name].join(' -> '),x);
 const bindings=Object.fromEntries(d.args.map((a,j)=>[a,info.args[j]]));const called=d.body.kind==='group'||(d.body.kind==='term'&&termInfo(d.body,bindings).kind==='call');
 if(called){const e=expand(d.body,bindings,[...stack,d.name],quantity,callLine||x.line);if(d.body.comments.some(c=>c.v.includes('@')))warn('Definition-body annotations are active only through this invoked process module.',d.line,'info');return {...e,comments:[...e.comments,...x.comments],sourceModule:info.name};}
 // A molecular definition is opaque structural data, not a graph operation.
 if(d.body.comments.some(c=>c.v.includes('@')))warn('Ignored annotation on molecular definition '+info.name+'; place it on the main invocation.',d.line);
 return {...x,kind:'species',species:info.name+'('+info.args.map(a=>a.map(t=>t.v).join('')).join(',')+')',structure:subst(d.body.tokens,bindings).map(t=>t.v).join(' '),quantity,line:callLine||x.line,sourceModule:info.name};
 }
 function checkReaction(x){const ts=x.tokens,arrows=ts.map((t,i)=>['->','<->'].includes(t.v)?i:-1).filter(i=>i>=0);if(arrows.length!==1)fail('A reaction must contain exactly one arrow.',x);const at=arrows[0],left=ts.slice(0,at);let right=ts.slice(at+1),rates=0;
 while(right[0]?.v==='{'){let depth=0,j=0;do{if(right[j].v==='{')depth++;if(right[j].v==='}')depth--;j++;}while(j<right.length&&depth);if(j===2)fail('Empty reaction rate.',x);right=right.slice(j);rates++;}
 if(rates>(ts[at].v==='<->'?2:1))fail('Too many reaction rates.',x);if(!left.length&&!right.length)fail('A reaction cannot have both sides empty.',x);if(ts[at].v==='<->'&&(!left.length||!right.length))fail('Reversible empty-side reactions are outside this subset.',x);
 function side(tokens){if(!tokens.length)return;let stack=[],part=[];const check=()=>{if(!part.length)fail('Missing reaction species around +.',x);const info=termInfo({...x,tokens:part},{});if(!['call','molecule'].includes(info.kind)||!Number.isSafeInteger(info.quantity)||info.quantity<1)fail('Reaction stoichiometry must be a positive integer.',x);if(info.kind==='call'){const d=p.defs.get(info.name);if(!d)fail('Undefined reaction module '+info.name,x);if(d.args.length!==info.args.length)fail('Reaction argument count mismatch for '+info.name,x);if(d.body.kind==='group')fail('A reaction species cannot be a multi-species process module.',x);}part=[];};for(const t of tokens){if(t.v==='+'&&!stack.length){check();continue;}part.push(t);if(OPEN[t.v])stack.push(OPEN[t.v]);else if(t.v===stack.at(-1))stack.pop();}check();}side(left);side(right);
 }
 const expandedRoots=p.roots.map(x=>{const e=expand(x);return e.implicit&&e.items.length===1&&e.items[0].kind==='group'?e.items[0]:e;});
 // Reserve explicit ports globally before suggesting any port, including nested groups.
 const reservedInputs=new Set(),reservedOutputs=new Set();function reserve(x){for(const a of annotationList(x)){if(a.fluid){if(!INPUT_PORTS.includes(a.fluid))fail('Invalid input port '+a.fluid,a);reservedInputs.add(a.fluid);}if(a.output){if(!OUTPUT_PORTS.includes(a.output))fail('Invalid output port '+a.output,a);reservedOutputs.add(a.output);}}for(const c of x.items||[])reserve(c);}expandedRoots.forEach(reserve);
 const usedInputs=new Set(reservedInputs),usedOutputs=new Set(reservedOutputs),speciesPorts=new Map();
 function inputPort(meta,species,line){if(meta.fluid){const prior=speciesPorts.get(species);if(prior&&prior!==meta.fluid)warn('The same species uses multiple input ports: '+species,line);speciesPorts.set(species,meta.fluid);return meta.fluid;}let port=speciesPorts.get(species);if(port)return port;port=INPUT_PORTS.find(q=>!usedInputs.has(q));if(!port){warn('No free architecture input port. Set @node fluid=... explicitly if a port is intentionally reused.',line,'error');return null;}usedInputs.add(port);speciesPorts.set(species,port);warn('Suggested input port '+port+' for '+species+'. Confirm or set @node fluid=... .',line);return port;}
 function outputPort(requested,line){if(requested)return requested;const port=OUTPUT_PORTS.find(q=>!usedOutputs.has(q));if(!port){warn('No free output port. Set @node output=... explicitly.',line,'error');return null;}usedOutputs.add(port);warn('Suggested output port '+port+'.',line);return port;}
 function output(tail,port,line,name){const n=add('OUTPUT',{name:name||'OUT_'+(serial+1),output:outputPort(port,line),line,sourceModule:'main'});connect(tail,n);return n;}
 function lowerBlock(root,index){const scope=new Map(),commands=[],current={index:index+1,line:root.line,mode:'preparation',roots:[],nodes:[],species:[]};blocks.push(current);const startCount=nodes.length;
 function register(id,tail,t){if(!id)return;if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(id))fail('Use a simple identifier in @node id.',t);if(scope.has(id))fail('Duplicate protocol id '+id+'.',t);scope.set(id,tail);}
 const isCommand=a=>['mix','split','output'].includes(a.kind)||(['heat','detect'].includes(a.kind)&&(a.id!==undefined||a.input!==undefined));
 function visit(x,isRoot=false){const as=annotationList(x),meta=baseMeta(as),cmds=as.filter(isCommand);for(const a of cmds){const start=as.indexOf(a)+1,end=as.findIndex((b,k)=>k>=start&&isCommand(b));commands.push({a,ops:as.slice(start,end<0?as.length:end).filter(b=>['heat','detect'].includes(b.kind))});}const opAs=cmds.length?[]:as;
 if(x.kind==='reaction'){checkReaction(x);if(as.length)fail('Operation annotations on a kinetic reaction are ambiguous. Put operations on an input/group or on a separate @mix/@split/@output comment.',x);const text=x.tokens.map(t=>t.v).join(' '),arrow=x.tokens.findIndex(t=>['->','<->'].includes(t.v));let right=x.tokens.slice(arrow+1);while(right[0]?.v==='{'){let depth=0,j=0;do{if(right[j].v==='{')depth++;if(right[j].v==='}')depth--;j++;}while(j<right.length&&depth);right=right.slice(j);}const type=arrow===0?'source':right.length===0?'sink':x.tokens[arrow].v==='<->'?'reversible':'reaction';reactions.push({text,line:x.line,type,block:index+1});warn(type==='source'||type==='sink'?'Continuous '+type+' reaction cannot be represented as a finite droplet DAG. A finite dosing/removal protocol is required.':'Kinetic reaction retained as metadata; it does not specify a physical mixing sequence.',x.line,type==='source'||type==='sink'?'error':'warning');return null;}
 if(x.kind==='dynamic'){warn('Timed or constant-population process is not a finite initial dispense. Define its physical protocol explicitly.',x.line,'error');observations.push({line:x.line,text:x.tokens.map(t=>t.v).join(' '),reason:'dynamic-process',block:index+1});return null;}
 if(x.kind==='species'){if(meta.output)fail('An initial species is not an output droplet. Annotate the enclosing group or use @output.',x);if(meta.count!==undefined)fail('count on an input is not a droplet count. Use @node value=... for its numeric field.',x);if(!x.quantity){if(as.length)fail('Zero initial species cannot carry a physical operation. Annotate a positive input or the group.',x);observations.push({species:x.species,quantity:0,line:x.line,reason:'zero-initial',block:index+1});return null;}
 const n=add('DISPENSE',{name:'pending',fluid:inputPort(meta,x.species,x.line),value:meta.value??meta.time??1,line:x.line,sourceModule:x.sourceModule||'literal',species:x.species,initialQuantity:x.quantity,structure:x.structure||x.species,protocolId:meta.id||null,sourceStart:x.start,sourceEnd:x.end,block:index+1});n.name=n.fluid||'UNMAPPED_'+n.id;current.species.push({species:x.species,quantity:x.quantity,node:n.id});const tail=applyOps(n,opAs,x.species);register(meta.id,tail,x);return tail;}
 if(meta.fluid)fail('fluid belongs on an initial species, not a process group.',x);let tails=x.items.map(c=>visit(c)).filter(Boolean);const explicitHere=commands.length>0;if(explicitHere){if(!isRoot)fail('Explicit protocol commands must belong to a top-level main block.',x);if(meta.id||meta.output||meta.value||meta.count||opAs.some(a=>['heat','detect'].includes(a.kind)))fail('With explicit commands, set parameters on @mix/@split/@output, not the enclosing group.',x);return tails;}
 if(!tails.length)return null;if(tails.length===1&&tails[0].type==='OUTPUT'&&!Object.keys(meta).length&&!opAs.length)return tails[0];if(tails.some(n=>n.type==='OUTPUT'))fail('A completed output cannot feed another mixture. Use separate main blocks or explicit protocol commands.',x);
 let tail;if(tails.length>1){const n=add('MIX',{name:meta.id||'MIX_'+(serial+1),count:tails.length,value:meta.value??meta.time??1,line:x.line,sourceModule:'main',block:index+1});if(meta.count!==undefined&&meta.count!==tails.length)fail('MIX count does not match its inputs.',x);tails.forEach(t=>connect(t,n));tail=n;warn('Parallel group interpreted as one '+tails.length+'-input physical MIX. This is a preparation convention, not DSD reaction ordering.',x.line);}
 else{tail=tails[0];if(meta.value!==undefined||meta.count!==undefined)fail('A one-input group has no MIX numeric fields.',x);}
 tail=applyOps(tail,opAs,'main');register(meta.id,tail,x);if(meta.output)tail=output(tail,meta.output,x.line);return tail;
 }
 const tails=visit(root,true);
 if(commands.length){current.mode='explicit';const pending=[...commands],defined=new Set(scope.keys());for(const {a} of commands){if(!a.id)fail('@'+a.kind+' requires id=...',a);if(defined.has(a.id))fail('Duplicate protocol id '+a.id,a);defined.add(a.id);if(a.kind==='mix'&&!a.inputs)fail('@mix requires inputs=A,B,...',a);if(a.kind!=='mix'&&!a.input)fail('@'+a.kind+' requires input=...',a);}
 while(pending.length){let progress=false;for(let j=0;j<pending.length;j++){const {a,ops}=pending[j],refs=a.kind==='mix'?a.inputs.split(','):[a.input];if(new Set(refs).size!==refs.length)fail('Duplicate input in '+a.id,a);if(refs.some(r=>!defined.has(r)))fail('Unknown protocol reference in '+a.id+': '+refs.filter(r=>!defined.has(r)).join(', '),a);if(refs.some(r=>!scope.has(r)))continue;const inputs=refs.map(r=>scope.get(r));if(inputs.some(n=>n.type==='OUTPUT'))fail('OUTPUT cannot be consumed.',a);let n;
 if(a.kind==='mix'){if(inputs.length<2)fail('MIX needs at least two distinct inputs.',a);if(a.count!==undefined&&a.count!==inputs.length)fail('MIX count does not match its inputs.',a);n=add('MIX',{name:a.id,count:inputs.length,value:a.value??1,line:a.line,sourceModule:'@mix',block:index+1});}
 else if(a.kind==='split'){if(a.count!==undefined&&a.count!==2)fail('SPLIT supports exactly two outputs.',a);if(ops.length)fail('Place HEAT/DETECT before SPLIT, not on it.',a);n=add('SPLIT',{name:a.id,count:2,value:a.value??1,line:a.line,sourceModule:'@split',block:index+1});}
 else if(['heat','detect'].includes(a.kind)){n=add(a.kind.toUpperCase(),{name:a.id,value:a.value??a.time??1,...(a.kind==='detect'?{count:a.count??1}:{}),line:a.line,sourceModule:'@'+a.kind,block:index+1});}
 else{if(ops.length)fail('Place HEAT/DETECT before OUTPUT.',a);n=add('OUTPUT',{name:a.id,output:outputPort(a.output,a.line),line:a.line,sourceModule:'@output',block:index+1});}
 n.protocolId=a.id;inputs.forEach(t=>connect(t,n));scope.set(a.id,applyOps(n,ops,'@'+a.kind));pending.splice(j--,1);progress=true;}
 if(!progress)fail('Dependency cycle in explicit protocol commands.',pending[0].a);}
 }else if(tails&&!Array.isArray(tails)&&tails.type!=='OUTPUT')output(tails,null,root.line);
 current.nodes=nodes.slice(startCount).map(n=>n.id);current.roots=nodes.slice(startCount).filter(n=>n.type==='DISPENSE').map(n=>n.id);
 }
 expandedRoots.forEach(lowerBlock);if(blocks.length>1)warn('Multiple top-level blocks are treated as independent preparations, with no inferred execution order.',blocks[1].line);
 if(!nodes.length)warn('No positive finite initial species were found. No physical assay graph can be constructed.',1,'error');
 try{validate({nodes,edges},false);}catch(e){if(!options.draft)throw e;warn(e.message,e.line,'error');}if(reactions.length)warn('Only preparation steps are shown. Molecular reaction pathways are not simulated or expanded.',1);
 for(let bi=0;bi<blocks.length;bi++){const r=p.roots[bi];let end=r.end;for(const c of r.comments||[])if(c.start>=r.end)end=Math.max(end,c.end);if(r.implicit)for(const x of r.items)for(const c of x.comments||[])end=Math.max(end,c.end);if(source[end-1]==='\r'&&source[end]==='\n')end--;blocks[bi].sourceStart=r.start;blocks[bi].sourceEnd=end;const comments=lex(source.slice(r.start,end)).filter(t=>t.kind==='comment'&&t.v.trim().startsWith('DSD-GRAPH-LAYOUT '));if(comments.length){try{const positions=JSON.parse(comments.at(-1).v.trim().slice(17));for(const id of blocks[bi].nodes){const n=nodes.find(x=>x.id===id),xy=positions[n.protocolId];if(xy&&Array.isArray(xy)&&xy.length===2&&xy.every(v=>Number.isFinite(v)&&v>=0&&v<=10000))n.position={x:xy[0],y:xy[1]};}}catch(_){warn('Ignored invalid graphical layout metadata.',r.line,'info');}}}
 const errors=diagnostics.filter(d=>d.severity==='error');return {schema:'dsd-main/6',mode:blocks.every(b=>b.mode==='explicit')?'main-explicit':blocks.every(b=>b.mode==='preparation')?'main-preparation':'main-mixed',ready:errors.length===0&&diagnostics.every(d=>d.severity!=='warning'),exportable:errors.length===0&&nodes.length>0,reviewRequired:diagnostics.some(d=>d.severity==='warning'),nodes,edges,blocks,observations,reactions,diagnostics,warnings:diagnostics.map(d=>d.message),selection:{blocks:blocks.length,definitions:p.defs.size},semantics:'Main-process preparation graph or explicit comment-defined droplet protocol. Not a molecular reaction graph or a simulation.',numericSemantics:'Initial quantities and reaction rates are retained separately; @node value is forwarded to MFSim without inferred units.'};
}
function validate(g,ports=true){const ns=new Map();for(const n of g.nodes){if(ns.has(n.id))fail('Duplicate graph ID.',n);ns.set(n.id,n);if(!['DISPENSE','MIX','SPLIT','HEAT','DETECT','OUTPUT'].includes(n.type))fail('Unknown operation type.',n);if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(n.name))fail('Unsafe or invalid graph label.',n);if(n.type!=='OUTPUT'&&(!Number.isFinite(n.value)||n.value<=0))fail('Invalid numeric value.',n);if(ports&&n.type==='DISPENSE'&&!INPUT_PORTS.includes(n.fluid))fail('Invalid input port.',n);if(ports&&n.type==='OUTPUT'&&!OUTPUT_PORTS.includes(n.output))fail('Invalid output port.',n);}
 const ins=new Map(g.nodes.map(n=>[n.id,0])),outs=new Map(ins),seen=new Set();for(const e of g.edges){if(!ns.has(e.source)||!ns.has(e.target))fail('Dangling graph edge.');const key=e.source+':'+e.target;if(seen.has(key))fail('Duplicate graph edge.');seen.add(key);ins.set(e.target,ins.get(e.target)+1);outs.set(e.source,outs.get(e.source)+1);}
 for(const n of g.nodes){const a=ins.get(n.id),b=outs.get(n.id);if(n.type==='DISPENSE'&&a!==0)fail('DISPENSE cannot have predecessors.',n);if(n.type==='MIX'&&(a<2||a!==n.count))fail('MIX count must equal its incoming edges.',n);if(!['DISPENSE','MIX'].includes(n.type)&&a!==1)fail(n.type+' requires one predecessor.',n);if(n.type==='SPLIT'&&(b!==2||n.count!==2))fail('SPLIT requires two distinct consumers.',n);if(n.type==='OUTPUT'&&b!==0)fail('OUTPUT cannot have consumers.',n);if(n.type==='DISPENSE'&&b<1)fail(n.name+' requires at least one consumer.',n);if(!['DISPENSE','SPLIT','OUTPUT'].includes(n.type)&&b!==1)fail(n.name+' requires one consumer. Add an explicit SPLIT for branching, and connect every input.',n);if(n.type==='DETECT'&&(!Number.isSafeInteger(n.count)||n.count<1))fail('Invalid DETECT count.',n);}
 const q=g.nodes.filter(n=>ins.get(n.id)===0).map(n=>n.id);let visited=0;while(q.length){const id=q.pop();visited++;for(const e of g.edges)if(e.source===id){ins.set(e.target,ins.get(e.target)-1);if(ins.get(e.target)===0)q.push(e.target);}}if(visited!==g.nodes.length)fail('Graph contains a cycle.');return true;
}
// A source node may supply multiple independent draws. Execution DAGs contain
// one DISPENSE occurrence per outgoing source edge; no implicit droplet split.
function toExecutionGraph(g){
 const outgoing=new Map(g.nodes.map(n=>[n.id,[]]));
 for(const e of g.edges)outgoing.get(e.source)?.push(e);
 const sources=g.nodes.filter(n=>n.type==='DISPENSE'&&outgoing.get(n.id).length>1);
 if(!sources.length)return g;
 const extra=sources.reduce((sum,n)=>sum+outgoing.get(n.id).length-1,0);
 if(g.nodes.length+extra>500)fail('Expanded execution graph exceeds 500 nodes. Reduce the number of draws.');
 let serial=Math.max(0,...g.nodes.map(n=>Number(n.id)||0));
 const nodes=g.nodes.map(n=>({...n})),edges=g.edges.map(e=>({...e}));
 const byId=new Map(nodes.map(n=>[n.id,n])),copies=new Map();
 const used=new Set(nodes.map(n=>n.protocolId).filter(Boolean));
 for(const source of sources){
  const refs=edges.filter(e=>e.source===source.id),ids=[source.id];
  refs.forEach((edge,index)=>{
   let n=byId.get(source.id);
   if(index){let protocolId=(source.protocolId||'SOURCE_'+source.id)+'_DRAW_'+(index+1);while(used.has(protocolId))protocolId+='_';used.add(protocolId);n={...source,id:++serial,protocolId};nodes.push(n);ids.push(n.id);edge.source=n.id;}
   Object.assign(n,{sourceNodeId:source.id,sourceProtocolId:source.protocolId||null,drawIndex:index+1,totalDraws:refs.length});
  });copies.set(source.id,ids);
 }
 // Expanded inputs need independent coordinates. Re-layout the output only.
 for(const n of nodes)delete n.position;
 const expandIds=ids=>ids.flatMap(id=>copies.get(id)||[id]);
 const blocks=g.blocks?.map(b=>({...b,nodes:expandIds(b.nodes),roots:expandIds(b.roots)}));
 return {...g,nodes,edges,...(blocks?{blocks}:{}),executionExpanded:true,
  sourceNodeCount:g.nodes.length,sourceEdgeCount:g.edges.length,
  dispenseSemantics:'Each outgoing source edge is a separate draw from the same port; value applies to each draw. Initial molecular quantity is not a reservoir-capacity constraint.'};
}
function code(g,options={}){if(!g.exportable)fail('MFSim export blocked: resolve the reported unsupported process or mapping errors.');if(g.reviewRequired&&!options.reviewed)fail('Review the proposed preparation and port mappings, then confirm before MFSim export.');validate(g);g=toExecutionGraph(g);validate(g);return ['// MFSim initial DAG: FileIn::ReadDagFromFile','// Main-process '+(g.mode==='main-explicit'?'explicit protocol':'preparation proposal; reviewed assumptions'),'DAGNAME(DSD_Assay)',...g.nodes.map(n=>{const fields=n.type==='DISPENSE'?[n.id,n.type,n.fluid,n.value,n.name]:n.type==='OUTPUT'?[n.id,n.type,n.output,n.name]:n.type==='HEAT'?[n.id,n.type,n.value,n.name]:[n.id,n.type,n.count,n.value,n.name];return 'NODE('+fields.join(',')+')';}),...g.edges.map(e=>'EDGE('+e.source+','+e.target+')')].join('\n');}
const api={parse,extract,lex,annotations,numberExpr,validate,toExecutionGraph,code,ParseError,INPUT_PORTS,OUTPUT_PORTS};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.DSDProtocol=api;
})(typeof globalThis!=='undefined'?globalThis:this);
