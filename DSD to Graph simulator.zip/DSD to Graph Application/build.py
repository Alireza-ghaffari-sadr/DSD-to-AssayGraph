from pathlib import Path
p = Path(__file__).resolve().parent
html = (p / 'index.html').read_text(encoding='utf-8')
html = html.replace('<link rel="stylesheet" href="style.css">', '<style>\n' + (p / 'style.css').read_text(encoding='utf-8') + '\n</style>')
for name in ['main.js', 'examples.js', 'editor-model.js', 'app.js', 'editor-ui.js']:
    code = (p / name).read_text(encoding='utf-8').replace('</script', '<\\/script')
    html = html.replace('<script src="' + name + '"></script>', '<script>\n' + code + '\n</script>')
(p / 'standalone.html').write_text(html, encoding='utf-8')
print('standalone.html created')

# Extract the embedded examples without a runtime dependency in the application.
import subprocess, json
examples = json.loads(subprocess.check_output(['node', '-e', "console.log(JSON.stringify(require('./examples.js')))"], cwd=p))
(p/'examples').mkdir(exist_ok=True)
for example in examples:
    (p/'examples'/example['file']).write_text(example['source'], encoding='utf-8')
